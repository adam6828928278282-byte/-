"""Offline planning checks. No network, credentials, canvas writes or generation."""
import argparse,json,math,pathlib,re,unicodedata

def words(text):
    return re.findall(r"[A-Za-z0-9]+(?:['’][A-Za-z0-9]+)*",text)

def normalize(text):
    return ' '.join(words(unicodedata.normalize('NFKC',text).lower()))

def estimate(group):
    seconds=0.0;details=[]
    for index,beat in enumerate(group.get('beats',[]),1):
        speech=0.0
        for line in beat.get('dialogues',[]):
            rate=float(line.get('rate',2.5));pause=float(line.get('pause_seconds',0))
            if rate<=0 or pause<0: raise ValueError('词速必须大于0，停顿不能为负数')
            speech+=len(words(line['text']))/rate+pause
        sync=float(beat.get('sync_action_seconds',0));extra=float(beat.get('extra_action_seconds',0));overlap=float(beat.get('speech_overlap_seconds',0))
        if min(sync,extra,overlap)<0 or overlap>speech: raise ValueError('动作或重叠秒数无效')
        if overlap and not beat.get('overlap_reason'): raise ValueError('抢话重叠必须说明原剧情依据')
        length=max(speech-overlap,sync)+extra
        seconds+=length;details.append({'beat':index,'spoken_seconds':round(speech,3),'content_seconds':round(length,3)})
    margin=float(group.get('margin_seconds',0))
    if margin<0: raise ValueError('余量不能为负数')
    if margin>0.5 and not group.get('margin_reason'): raise ValueError('超过0.5秒余量必须说明原因')
    requested=math.ceil(seconds+margin-1e-9)
    supported=group.get('supported_durations')
    chosen=min((n for n in supported if n>=requested),default=None) if supported else requested
    return {'content_seconds':round(seconds,3),'margin_seconds':margin,'minimum_seconds':requested,'selected_supported_seconds':chosen,'beats':details}

def check(plan):
    errors=[];warnings=[];estimates=[];units=plan.get('source_units',[]);groups=plan.get('groups',[])
    ids=[u.get('id') for u in units]
    if not units or len(ids)!=len(set(ids)) or any(not x for x in ids): errors.append('原文台账为空、ID为空或重复')
    if not groups: errors.append('没有执行组')
    lookup={u.get('id'):u for u in units};seen={};previous=None
    for group in groups:
        gid=group.get('id','未命名组')
        if not 0<float(group.get('duration',0))<=30: errors.append(f'{gid}: 组件秒数必须大于0且不超过30')
        if group.get('resolution')!='480p': warnings.append(f'{gid}: 非默认480p，需要用户要求或明确差异说明')
        for uid in group.get('unit_ids',[]):
            if uid not in lookup: errors.append(f'{gid}: 未知原文ID {uid}')
            seen.setdefault(uid,[]).append(gid)
        if previous and group.get('same_scene',True) and previous.get('end_state')!=group.get('start_state'):
            errors.append(f'{gid}: 同场起始状态ID与上组末态不一致')
        if not group.get('start_state') or not group.get('end_state'): errors.append(f'{gid}: 缺起始或结束状态ID')
        if not group.get('beats'): warnings.append(f'{gid}: 未填写节拍，无法核验估时')
        else:
            try:
                e=estimate(group);estimates.append({'group_id':gid,**e})
                if e['minimum_seconds']>30: errors.append(f'{gid}: 内容超过30秒，需保留原文继续拆组')
                if group.get('duration',0)<e['minimum_seconds']: errors.append(f'{gid}: 组件时间小于内容估时')
                if e['selected_supported_seconds'] is None: errors.append(f'{gid}: 平台没有可容纳内容的支持时长')
                if e['selected_supported_seconds'] and group.get('duration')!=e['selected_supported_seconds']: warnings.append(f'{gid}: 组件秒数不是当前输入对应的最短支持值，请核对节奏依据')
            except (ValueError,TypeError,KeyError) as ex: errors.append(f'{gid}: {ex}')
        previous=group
    for unit in units:
        uid=unit.get('id');linked=seen.get(uid,[])
        if unit.get('required',True) and not linked: errors.append(f'{uid}: 原文条目未安排到任何组')
        if len(linked)>1: warnings.append(f'{uid}: 跨组重复引用，请人工核对是合法连续分句还是重复表演')
        if unit.get('kind')=='dialogue' and linked:
            if not normalize(unit.get('text','')):
                errors.append(f'{uid}: 台词为空或不属于此英文词速检查器的支持范围')
                continue
            actual=' '.join(g.get('prompt','') for g in groups if g.get('id') in linked)
            if normalize(unit.get('text','')) not in normalize(actual):
                if len(linked)>1: warnings.append(f'{uid}: 跨组完整原句未连续匹配，需人工检查所有分句的原顺序与完整性')
                else: errors.append(f'{uid}: 已引用ID但提示词没有完整原台词')
        elif linked: warnings.append(f'{uid}: 动作/主观段只验证了ID关联，仍须人工核对内容与成片')
    return {'ok':not errors,'scope':'仅验证输入计划，不证明画布已保存或成片完整','errors':errors,'warnings':warnings,'estimates':estimates}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('plan',type=pathlib.Path);args=parser.parse_args()
    result=check(json.loads(args.plan.read_text(encoding='utf8')))
    print(json.dumps(result,ensure_ascii=False,indent=2));raise SystemExit(0 if result['ok'] else 1)
